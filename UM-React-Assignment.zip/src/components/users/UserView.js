import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import axios from "axios";

const UserView = () => {
  const [user, setUser] = useState({

  });
  const { id } = useParams();
  useEffect(() => {
    loadUser();
  }, []);
  const loadUser = async () => {
    const res = await axios.get(`http://localhost:3003/users/${id}`);
    setUser(res.data);
  };
  return (
    <div className="container">
     
    <div className="modal-dialog-dark">
        <div class="modal-content">
            
            <div class="modal-header">
            <h2 className="display-4">User Id: {id}</h2>
                  
      <Link type="button" class="btn btn-close" to="/"></Link>
      </div>                         
        <div class="modal-body">
        <h3>Name: {user.fist_name} {user.last_name}</h3>
        <h3>Username: {user.username}</h3>
        <h3>Profile: {user.profile}</h3>
        <h3>Email address: {user.email}</h3>
      <br/>
          <div class="modal-footer">
             <Link className="btn btn-primary" to="/">
        back to Home
      </Link>
        
          </div>
      </div>
                
                </div>
            </div>
        </div>
  );
};

export default UserView;
