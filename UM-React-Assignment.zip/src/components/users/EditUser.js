import React, { useState, useEffect } from "react";
import {Link} from 'react-router-dom';
import axios from "axios";
import { useHistory, useParams } from "react-router-dom";

const EditUser= () => {
  let history = useHistory();
 const { id } = useParams();
  const [user, setUser] = useState({
    fist_name: "",
    last_name: "",
    profile: "",
    username: "",
    email: "",
    password: "",
  });

  const { fist_name, last_name, profile,username, email, password } = user;
  const onInputChange = e => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

 useEffect(() => {
    loadUser();
  }, [] );

  const onSubmit = async e => {
    e.preventDefault();
    await axios.put(`http://localhost:3003/users/${id}`, user);
    history.push("/");
  };

  const loadUser = async () => {
    const result = await axios.get(`http://localhost:3003/users/${id}`);
    setUser(result.data);
  };

  return (
    <div className="container">
     
    <div className="modal-dialog-dark">
        <div class="modal-content">
            
            <div class="modal-header">
         
        <h4 className="text-center mb-3">Edit a Profile</h4>
                <Link type="button" class="btn btn-close" to="/"></Link>
                       
            </div>
            
            <div class="modal-body">
                
            <form onSubmit={e => onSubmit(e)}>
            <div className="form-group">
          <label>First Name</label> <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter first name"
              name="fist_name"
              value={fist_name}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
          <label>Last Name</label> <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter last name"
              name="last_name"
              value={last_name}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
          <label>Profiles</label>
          <select  className="form-control" name="profile" value={profile}  onChange={e => onInputChange(e)}>
              <option>Select...</option>
              <option>PHP Developer</option>
              <option>React Developer</option>
              <option>Java Developer</option>
              <option>Web Developer</option> </select>                        
          
          </div>
          <div className="form-group">
          <label>Username</label> <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter your username"
              name="username"
              value={username}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
          <label>Email Address</label><input
              type="email"
              className="form-control form-control-lg"
              placeholder="Enter your email id"
              name="email"
              value={email}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
          <label>Password</label><input
              type="password"
              className="form-control form-control-lg"
              placeholder="Enter Password"
              name="password"
              value={password}
              onChange={e => onInputChange(e)} disabled
            />
          </div>
          <br/>
          <div class="modal-footer">
          <Link className="btn btn-primary" to="/">
        back to Home
      </Link>
          <button className="btn btn-warning btn-block">Update Profile</button>
        
          </div>
          </form>
                
                </div>
                
            </div>
        </div>
    </div>
  );
};

export default EditUser;
