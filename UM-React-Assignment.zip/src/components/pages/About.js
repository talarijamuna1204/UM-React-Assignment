import React from 'react';

const About = () => {
  return (         
    <div className="container">
        <div className="w-75 mx-auto shadow p-5">
     
        <h4 className="text-center mg-10 ">About Us</h4>
        <div class="modal-header">
         
         <h4 className="text-left ">Vision</h4>
                        
             </div>
             
             <div class="modal-body">
                 
             We help you make better operational strategies using AI and predictive algorithm. Our primary goal is to improve your plant's operational efficiency.
                 </div>
                 <div class="modal-header">
         
        <h4 className="text-left ">Our Story</h4>
                       
            </div>
            
            <div class="modal-body">
                
            Machstatz was conceptualized with one and one aim alone - take organizations engaged in the machine intensive industries next level.

So far, AI and IoT technologies have led various breakthroughs in smart technology and robotics. It's about time that traditional industries of manufacturing, assembly line, extraction etc, also benefit from AI and IoT.

With that in mind, Machstatz began in 2017 with a small team of highly experienced techies. Our core team has extensive experience and expertise in diverse fields of advanced tech such as Industrial Instrumentation & Automation, Big Data, Database Management, Data Security, Data Analytics, Artificial Intelligence and Machine Learning.

In short, our team is well equipped with the expertise needed to upgrade your organization with Industrial IoT.</div></div></div>




 
  );
};
export default About;