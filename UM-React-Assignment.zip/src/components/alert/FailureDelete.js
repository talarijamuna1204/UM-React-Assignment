import React from 'react';

const FailureDelete = () => {
  return (         
    <div className="alert alert-success" role="alert">

Error!! Unable to delete the user or user may not exist.
       </div>
  


 
  );
};
export default FailureDelete;