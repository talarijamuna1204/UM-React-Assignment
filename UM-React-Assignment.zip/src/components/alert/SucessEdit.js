import React from 'react';

const SuccessEdit = () => {
  return (         
    <div className="alert alert-success" role="alert">
    User Profile Updated successfully.
       </div>

 
  );
};
export default SuccessEdit;