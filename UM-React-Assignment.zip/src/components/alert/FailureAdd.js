import React from 'react';

const FailureAdd = () => {
  return (         
    <div className="alert alert-success" role="alert">
   User with provided email or username is already exist.

         </div>
 
  );
};
export default FailureAdd;