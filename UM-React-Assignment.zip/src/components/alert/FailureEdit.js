import React from 'react';

const FailureEdit = () => {
  return (         
    <div className="alert alert-success" role="alert">
   Error!! User with provided email or username is already exist.

         </div>




 
  );
};
export default FailureEdit;