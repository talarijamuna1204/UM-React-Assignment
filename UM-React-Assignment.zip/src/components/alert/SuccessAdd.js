import React from 'react';

const SuccessAdd = () => {
  return (         
    <div className="alert alert-success" role="alert">
        Created the new user successfully.
         </div>
  );
};
export default SuccessAdd;