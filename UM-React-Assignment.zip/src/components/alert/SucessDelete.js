import React from 'react';

const SuccessDelete = () => {
  return (         
    <div className="alert alert-success" role="alert">
  User deleted successfully.
     </div>


 
  );
};
export default SuccessDelete;